package lab7;

/**
 * Skapar klassen Pet och testar dess metoder (WIP)
 * 
 * @author 24adsa02 (Adam Sandén)
 * @version 20241015
 */
public class P7_3 {
	public static void main(String[] args) {

	}
}
